# HEDERA

Hedera/HBAR is the execution and token settlement layer for V1 testnet readiness.
