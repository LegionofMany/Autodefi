# OPERATOR RUNBOOK V1

Run pnpm setup:v1-local, then pnpm dev, then open /autodefi/institutional.
