# STABLECOIN RAILS

Stable-value rails are used for loan principal, dealer funding, borrower payments and accounting.
