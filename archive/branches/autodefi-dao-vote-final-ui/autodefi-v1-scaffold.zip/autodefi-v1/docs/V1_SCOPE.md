# V1 SCOPE

V1 is internal-first: dealer OS, AI audit, internal funding, tier pools, stable treasury, ADF utility, servicing and reconciliation.
