# DEAL FLOW

Dealer submits approved deal → AI audit → tier pool funding → dealer paid in full → borrower servicing → yield distribution.
