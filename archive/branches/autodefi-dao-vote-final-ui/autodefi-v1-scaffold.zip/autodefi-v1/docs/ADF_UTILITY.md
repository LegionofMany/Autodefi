# ADF UTILITY

ADF is utility: staking, collateral, dealer access, boosts, governance and rewards. It is not the default loan payment currency.
