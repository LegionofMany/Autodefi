# V1 COMPLETION CHECKLIST

V1 is complete only after pnpm complete:v1 passes locally plus CI and deployment smoke checks.
