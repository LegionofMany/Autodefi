import { AutoDeFiShell } from "@/components/autodefi/AutoDeFiShell";
import { PageHeader } from "@/components/autodefi/PageHeader";
import { StatTile } from "@/components/autodefi/StatTile";
import { CyberCard } from "@/components/autodefi/CyberCard";
export default function Page() {
  return <AutoDeFiShell>
    <PageHeader eyebrow="Standalone Institutional Portal · V1" title="Blockchain LP capital to dealership funding infrastructure." description="Dealer paid-in-full funding, stablecoin servicing, ADF utility, Hedera execution and tier-pool yield distribution." />
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16,marginTop:32}}>
      <StatTile label="Dealer Payouts" value="$32,000" />
      <StatTile label="Active Principal" value="$31,480" />
      <StatTile label="Tier Yield" value="$157.95" />
      <StatTile label="ADF Collateral" value="5,000" />
    </div>
    <CyberCard title="Core V1 Rule"><p>Dealer gets funded in full. Borrower repays through stable-value rails. Interest distributes to matching tier LPs/stakers.</p></CyberCard>
  </AutoDeFiShell>
}
