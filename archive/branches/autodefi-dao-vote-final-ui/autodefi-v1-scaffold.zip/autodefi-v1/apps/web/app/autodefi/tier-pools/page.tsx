import { AutoDeFiShell } from "@/components/autodefi/AutoDeFiShell";
import { PageHeader } from "@/components/autodefi/PageHeader";
import { CyberCard } from "@/components/autodefi/CyberCard";
export default function Page() {
  return <AutoDeFiShell>
    <PageHeader eyebrow="AutoDeFi V1" title="Tier pool yield distribution." description="This page follows the locked dark cyber-finance visual system and V1 demo flow." />
    <CyberCard title="V1 Demo State"><p>Live integration hooks and fallbacks are ready for the next hardening pass.</p></CyberCard>
  </AutoDeFiShell>
}
