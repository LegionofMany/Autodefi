export function StatTile({ label, value }: { label: string; value: string }) {
  return <div className="ad-panel" style={{borderRadius:24,padding:20}}>
    <p style={{color:"#94a3b8",fontSize:12,letterSpacing:2,textTransform:"uppercase"}}>{label}</p>
    <p style={{fontSize:28,fontWeight:900,color:"#00ff9d"}}>{value}</p>
  </div>
}
