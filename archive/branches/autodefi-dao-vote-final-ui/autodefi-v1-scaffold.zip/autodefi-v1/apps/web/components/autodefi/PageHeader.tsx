export function PageHeader({ eyebrow, title, description }: { eyebrow?: string; title: string; description?: string }) {
  return <header>
    {eyebrow && <p style={{color:"#00ff9d",letterSpacing:3,fontWeight:900}}>{eyebrow}</p>}
    <h1 className="ad-text-gradient" style={{fontSize:48,maxWidth:1100}}>{title}</h1>
    {description && <p style={{color:"#94a3b8",maxWidth:900}}>{description}</p>}
  </header>
}
