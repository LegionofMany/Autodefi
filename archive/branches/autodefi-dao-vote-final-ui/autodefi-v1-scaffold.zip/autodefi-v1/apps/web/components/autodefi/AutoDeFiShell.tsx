import Link from "next/link";
export function AutoDeFiShell({ children }: { children: React.ReactNode }) {
  const links = ["/autodefi/institutional","/autodefi/dealer-command","/autodefi/borrower-command","/autodefi/tier-pools","/autodefi/stable-treasury","/autodefi/adf-utility","/autodefi/ai-risk"];
  return <div style={{display:"flex",minHeight:"100vh"}}>
    <aside style={{width:280,padding:18,borderRight:"1px solid rgba(96,165,250,.2)",background:"rgba(2,6,23,.9)"}}>
      <div className="ad-panel" style={{padding:16,borderRadius:24,marginBottom:16}}>
        <p style={{color:"#00ff9d",letterSpacing:3,fontSize:12,fontWeight:900}}>VOLTAIRE PROTOCOLS</p>
        <h2>AutoDeFi</h2>
        <p style={{color:"#94a3b8"}}>Institutional funding terminal</p>
      </div>
      {links.map(l=><Link key={l} href={l} style={{display:"block",color:"#cbd5e1",padding:"12px 10px",textDecoration:"none"}}>{l.replace("/autodefi/","")}</Link>)}
    </aside>
    <main style={{flex:1,padding:32}}>{children}</main>
  </div>
}
