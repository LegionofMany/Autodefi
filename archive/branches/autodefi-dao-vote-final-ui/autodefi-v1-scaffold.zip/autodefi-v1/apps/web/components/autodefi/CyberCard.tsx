export function CyberCard({ title, children }: { title?: string; children: React.ReactNode }) {
  return <section className="ad-panel" style={{borderRadius:28,padding:24,marginTop:20}}>
    {title && <h2 style={{marginTop:0}}>{title}</h2>}
    {children}
  </section>
}
