import { existsSync } from "node:fs";
const required = ["apps/web","services/auth","services/finance","services/ai","services/token","services/api-gateway","packages/types","packages/config","packages/backend-auth","prisma/schema.prisma","scripts","docs","package.json","README.md",".env.example"];
let failed = false;
for (const p of required) { if (!existsSync(p)) { console.error(`❌ ${p}`); failed = true; } else console.log(`✅ ${p}`); }
if (failed) process.exit(1);
