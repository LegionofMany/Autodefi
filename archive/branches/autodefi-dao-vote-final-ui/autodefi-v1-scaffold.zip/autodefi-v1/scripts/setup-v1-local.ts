import { execSync } from "node:child_process";
for (const cmd of ["pnpm install","docker compose up -d","pnpm db:validate","pnpm db:migrate","pnpm seed:v1-demo","pnpm verify:v1-demo"]) {
  execSync(cmd, { stdio: "inherit" });
}
