import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
const forbidden = ["HEDERA_OPERATOR_PRIVATE_KEY=302", "PRIVATE KEY-----"];
function walk(d:string):string[]{ if(!statSync(d,{throwIfNoEntry:false})) return []; return readdirSync(d).flatMap(e=>{ const p=join(d,e); if(["node_modules",".git","dist",".next"].includes(e)) return []; return statSync(p).isDirectory()?walk(p):[p];});}
for (const f of walk(".")) { if (f.includes("node_modules")) continue; try { const c=readFileSync(f,"utf8"); for(const x of forbidden) if(c.includes(x)){ console.error(`❌ secret-like value in ${f}`); process.exit(1);} } catch{} }
console.log("✅ security check passed");
