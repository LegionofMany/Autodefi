import { execSync } from "node:child_process";
for (const cmd of ["pnpm audit:v1-ready","pnpm build","pnpm run:v1-flow"]) {
  execSync(cmd, { stdio: "inherit" });
}
console.log("✅ AutoDeFi V1 completion gate passed locally.");
