import { readFileSync } from "node:fs";
const env = readFileSync(".env.example","utf8");
for (const k of ["DATABASE_URL","JWT_SECRET","NEXT_PUBLIC_API_URL","HEDERA_NETWORK","ADF_TOKEN_ID"]) {
  if (!env.includes(k+"=")) { console.error(`❌ Missing ${k}`); process.exit(1); }
}
console.log("✅ env audit passed");
