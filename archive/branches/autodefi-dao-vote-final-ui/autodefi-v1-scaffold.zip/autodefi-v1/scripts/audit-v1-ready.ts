import { execSync } from "node:child_process";
for (const cmd of ["pnpm audit:v1-structure","pnpm audit:v1-env","pnpm db:validate","pnpm security:check"]) {
  execSync(cmd, { stdio: "inherit" });
}
console.log("✅ V1 readiness audit passed.");
