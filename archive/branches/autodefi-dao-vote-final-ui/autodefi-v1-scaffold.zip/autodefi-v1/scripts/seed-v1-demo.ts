import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { V1_DEMO } from "./v1-demo-constants";

const prisma = new PrismaClient();

async function user(email: string, role: string) {
  return prisma.user.upsert({
    where: { email },
    create: { email, role, password: await bcrypt.hash(V1_DEMO.password, 10) },
    update: { role }
  });
}

async function main() {
  await import("./seed-defaults");

  const admin = await user(V1_DEMO.users.admin, "admin");
  const dealerOwner = await user(V1_DEMO.users.dealer, "dealer");
  const borrower = await user(V1_DEMO.users.borrower, "borrower");
  const lp = await user(V1_DEMO.users.lp, "lp");
  await user(V1_DEMO.users.investor, "investor");
  await user(V1_DEMO.users.dao, "dao");

  await prisma.userWallet.upsert({
    where: { walletAddress: V1_DEMO.wallets.lp },
    create: { userId: lp.id, walletAddress: V1_DEMO.wallets.lp, verified: true },
    update: { verified: true }
  });
  await prisma.userWallet.upsert({
    where: { walletAddress: V1_DEMO.wallets.borrower },
    create: { userId: borrower.id, walletAddress: V1_DEMO.wallets.borrower, verified: true },
    update: { verified: true }
  });

  const dealer = await prisma.dealer.upsert({
    where: { id: V1_DEMO.dealerId },
    create: { id: V1_DEMO.dealerId, name: "ZONYCS Demo Motors", ownerId: dealerOwner.id },
    update: { name: "ZONYCS Demo Motors", ownerId: dealerOwner.id }
  });

  const vehicle = await prisma.vehicle.upsert({
    where: { vin: V1_DEMO.vin },
    create: { vin: V1_DEMO.vin, make: "Tesla", model: "Model 3", trim: "Long Range", year: 2022, price: 38000, dealerId: dealer.id },
    update: { price: 38000, dealerId: dealer.id }
  });

  const pool = await prisma.tierPool.upsert({
    where: { riskTier: "tier_2_standard" },
    create: { poolKey: "tier_2_standard_pool", riskTier: "tier_2_standard", name: "Tier 2 Standard Pool", availableLiquidity: 250000 },
    update: { availableLiquidity: 218520, activePrincipal: 31480, totalPrincipalFunded: 32000, totalInterestEarned: 215, totalYieldDistributed: 157.95 }
  });

  const position = await prisma.tierPoolPosition.create({
    data: {
      poolId: pool.id, userId: lp.id, walletAddress: V1_DEMO.wallets.lp, riskTier: "tier_2_standard",
      principalAmount: 250000, adfStakedAmount: 100000, boostMultiplier: 1.2, effectiveWeight: 300000, metadata: V1_DEMO.metadata
    } as any
  }).catch(async () => prisma.tierPoolPosition.findFirstOrThrow({ where: { walletAddress: V1_DEMO.wallets.lp, riskTier: "tier_2_standard" }}));

  const deal = await prisma.deal.upsert({
    where: { dealNumber: V1_DEMO.dealNumber },
    create: {
      dealNumber: V1_DEMO.dealNumber, dealerId: dealer.id, borrowerUserId: borrower.id, vehicleId: vehicle.id,
      status: "funded", riskTier: "tier_2_standard", amountFinanced: 32000, approvedAmount: 32000,
      approvedRate: 14.99, approvedTerm: 60, metadata: V1_DEMO.metadata
    },
    update: { status: "funded", riskTier: "tier_2_standard", approvedAmount: 32000 }
  });

  await prisma.servicedLoan.upsert({
    where: { id: V1_DEMO.loanId },
    create: {
      id: V1_DEMO.loanId, dealId: deal.id, dealerId: dealer.id, borrowerUserId: borrower.id, vehicleId: vehicle.id,
      principal: 31480, rate: 14.99, termMonths: 60, paymentAmount: 735, riskTier: "tier_2_standard", status: "active", metadata: V1_DEMO.metadata
    },
    update: { principal: 31480, status: "active" }
  });

  await prisma.dealerFullFundingPayout.upsert({
    where: { payoutNumber: V1_DEMO.dealerPayoutNumber },
    create: {
      payoutNumber: V1_DEMO.dealerPayoutNumber, dealId: deal.id, loanId: V1_DEMO.loanId, dealerId: dealer.id, tierPoolId: pool.id,
      riskTier: "tier_2_standard", currencyCode: "USD", stableAssetSymbol: "USDC", approvedAmount: 32000, payoutAmount: 32000,
      status: "executed", txHash: "0xdemo_dealer_full_payout_tx", executedAt: new Date(), metadata: V1_DEMO.metadata
    },
    update: { status: "executed", payoutAmount: 32000 }
  });

  const payment = await prisma.stablePaymentIntent.upsert({
    where: { intentNumber: V1_DEMO.paymentIntentNumber },
    create: {
      intentNumber: V1_DEMO.paymentIntentNumber, loanId: V1_DEMO.loanId, dealId: deal.id, dealerId: dealer.id,
      borrowerUserId: borrower.id, walletAddress: V1_DEMO.wallets.borrower, amount: 735, assetSymbol: "USDC",
      status: "posted", txHash: "0xdemo_borrower_payment_tx", confirmedAt: new Date(), metadata: V1_DEMO.metadata
    },
    update: { status: "posted", amount: 735 }
  });

  const allocation = await prisma.stablePaymentAllocation.create({
    data: { paymentIntentId: payment.id, loanId: V1_DEMO.loanId, borrowerUserId: borrower.id, totalAmount: 735, principalAmount: 520, interestAmount: 215, lpYieldAmount: 157.95, metadata: V1_DEMO.metadata }
  }).catch(() => prisma.stablePaymentAllocation.findFirstOrThrow({ where: { paymentIntentId: payment.id }}));

  const yieldEvent = await prisma.tierPoolYieldEvent.upsert({
    where: { eventNumber: V1_DEMO.yieldEventNumber },
    create: {
      eventNumber: V1_DEMO.yieldEventNumber, poolId: pool.id, loanId: V1_DEMO.loanId, dealId: deal.id, dealerId: dealer.id,
      borrowerUserId: borrower.id, paymentIntentId: payment.id, paymentAllocationId: allocation.id, riskTier: "tier_2_standard",
      totalPaymentAmount: 735, principalReturned: 520, grossInterest: 215, treasuryFee: 21.5, insuranceReserveAmount: 12.9,
      dealerReserveAmount: 22.65, distributableYield: 157.95
    },
    update: { status: "posted" }
  });

  await prisma.tierPoolYieldDistribution.create({
    data: { yieldEventId: yieldEvent.id, poolId: pool.id, positionId: position.id, userId: lp.id, walletAddress: V1_DEMO.wallets.lp, riskTier: "tier_2_standard", baseWeight: 250000, boostMultiplier: 1.2, distributionAmount: 157.95 }
  }).catch(() => undefined);

  await prisma.aDFCollateralLock.upsert({
    where: { lockNumber: V1_DEMO.collateralLockNumber },
    create: {
      lockNumber: V1_DEMO.collateralLockNumber, dealId: deal.id, loanId: V1_DEMO.loanId, borrowerUserId: borrower.id,
      walletAddress: V1_DEMO.wallets.borrower, riskTier: "tier_2_standard", stableLoanAmount: 32000,
      adfAmountLocked: 5000, collateralPercent: 6.5, hederaTxHash: "0xdemo_adf_collateral_lock_tx", metadata: V1_DEMO.metadata
    },
    update: { status: "locked", adfAmountLocked: 5000 }
  });

  await prisma.aIDealAudit.upsert({
    where: { auditNumber: V1_DEMO.auditNumber },
    create: { auditNumber: V1_DEMO.auditNumber, dealId: deal.id, recommendation: "approve", finalTier: "tier_2_standard", confidenceScore: 0.91, metadata: V1_DEMO.metadata },
    update: { recommendation: "approve", finalTier: "tier_2_standard" }
  });

  await prisma.borrowerReceipt.upsert({
    where: { receiptNumber: V1_DEMO.receiptNumber },
    create: { receiptNumber: V1_DEMO.receiptNumber, borrowerUserId: borrower.id, loanId: V1_DEMO.loanId, amount: 735, metadata: V1_DEMO.metadata },
    update: { amount: 735 }
  });

  await prisma.reconciliationRun.deleteMany({ where: { runType: "v1_demo" } });
  const rec = await prisma.reconciliationRun.create({ data: { runType: "v1_demo", status: "completed", checkedCount: 3, matchedCount: 3, completedAt: new Date() }});
  await prisma.reconciliationItem.createMany({ data: [
    { runId: rec.id, transactionHash: "0xdemo_dealer_full_payout_tx", action: "dealer_payout", status: "matched", expectedAmount: 32000, actualAmount: 32000, metadata: V1_DEMO.metadata },
    { runId: rec.id, transactionHash: "0xdemo_borrower_payment_tx", action: "borrower_payment", status: "matched", expectedAmount: 735, actualAmount: 735, metadata: V1_DEMO.metadata },
    { runId: rec.id, transactionHash: "0xdemo_adf_collateral_lock_tx", action: "adf_collateral", status: "matched", expectedAmount: 5000, actualAmount: 5000, metadata: V1_DEMO.metadata }
  ]});

  console.log("✅ V1 demo seeded.");
}
main().finally(() => prisma.$disconnect());
