import { PrismaClient } from "@prisma/client";
import { V1_DEMO } from "./v1-demo-constants";
const prisma = new PrismaClient();

async function main() {
  await prisma.reconciliationItem.deleteMany({ where: { metadata: { path: ["demo"], equals: true }} as any });
  await prisma.reconciliationRun.deleteMany({ where: { runType: "v1_demo" }});
  await prisma.v1DashboardSnapshot.deleteMany({ where: { scopeId: "demo" }});
  await prisma.tierPoolYieldDistribution.deleteMany({ where: { walletAddress: V1_DEMO.wallets.lp }});
  await prisma.tierPoolYieldEvent.deleteMany({ where: { eventNumber: V1_DEMO.yieldEventNumber }});
  await prisma.stablePaymentAllocation.deleteMany({});
  await prisma.stablePaymentIntent.deleteMany({ where: { intentNumber: V1_DEMO.paymentIntentNumber }});
  await prisma.borrowerReceipt.deleteMany({ where: { receiptNumber: V1_DEMO.receiptNumber }});
  await prisma.borrowerNotice.deleteMany({ where: { metadata: { path: ["demo"], equals: true }} as any });
  await prisma.dealerTask.deleteMany({ where: { metadata: { path: ["demo"], equals: true }} as any });
  await prisma.aDFUserUtilitySnapshot.deleteMany({ where: { metadata: { path: ["demo"], equals: true }} as any });
  await prisma.aDFDealerAccessPosition.deleteMany({ where: { walletAddress: V1_DEMO.wallets.dealer }});
  await prisma.aDFCollateralLock.deleteMany({ where: { lockNumber: V1_DEMO.collateralLockNumber }});
  await prisma.dealerFullFundingPayout.deleteMany({ where: { payoutNumber: V1_DEMO.dealerPayoutNumber }});
  await prisma.servicedPaymentSchedule.deleteMany({ where: { loanId: V1_DEMO.loanId }});
  await prisma.servicedLoan.deleteMany({ where: { id: V1_DEMO.loanId }});
  await prisma.aIDealAudit.deleteMany({ where: { auditNumber: V1_DEMO.auditNumber }});
  await prisma.deal.deleteMany({ where: { dealNumber: V1_DEMO.dealNumber }});
  await prisma.vehicle.deleteMany({ where: { vin: V1_DEMO.vin }});
  await prisma.tierPoolPosition.deleteMany({ where: { walletAddress: V1_DEMO.wallets.lp }});
  await prisma.dealer.deleteMany({ where: { id: V1_DEMO.dealerId }});
  await prisma.userWallet.deleteMany({ where: { walletAddress: { in: [V1_DEMO.wallets.lp, V1_DEMO.wallets.borrower, V1_DEMO.wallets.dealer] }}});
  await prisma.user.deleteMany({ where: { email: { in: Object.values(V1_DEMO.users) }}});
  console.log("✅ V1 demo reset.");
}
main().finally(() => prisma.$disconnect());
