import { PrismaClient } from "@prisma/client";
import { V1_DEMO } from "./v1-demo-constants";
const prisma = new PrismaClient();

async function must(label: string, value: unknown) {
  if (!value) {
    console.error(`❌ Missing ${label}`);
    process.exit(1);
  }
  console.log(`✅ ${label}`);
}

async function main() {
  await must("demo deal", await prisma.deal.findUnique({ where: { dealNumber: V1_DEMO.dealNumber }}));
  const payout = await prisma.dealerFullFundingPayout.findUnique({ where: { payoutNumber: V1_DEMO.dealerPayoutNumber }});
  await must("dealer full payout", payout && payout.status === "executed");
  const loan = await prisma.servicedLoan.findUnique({ where: { id: V1_DEMO.loanId }});
  await must("active loan", loan && loan.status === "active");
  const payment = await prisma.stablePaymentIntent.findUnique({ where: { intentNumber: V1_DEMO.paymentIntentNumber }});
  await must("posted payment", payment && payment.status === "posted");
  const yieldEvent = await prisma.tierPoolYieldEvent.findUnique({ where: { eventNumber: V1_DEMO.yieldEventNumber }});
  await must("yield event", yieldEvent && yieldEvent.status === "posted");
  const lock = await prisma.aDFCollateralLock.findUnique({ where: { lockNumber: V1_DEMO.collateralLockNumber }});
  await must("ADF collateral lock", lock && lock.status === "locked");
  console.log("\n✅ V1 demo verified.");
}
main().finally(() => prisma.$disconnect());
