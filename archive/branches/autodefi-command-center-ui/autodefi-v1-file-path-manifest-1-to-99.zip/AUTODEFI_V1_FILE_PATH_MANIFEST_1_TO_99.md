# AutoDeFi V1 — Ordered File Path Manifest (1–99)

Use this as the downloadable/import order for the V1 scaffold and hardening backlog.

Items 1–78 are in the first physical scaffold ZIP. Items 79–99 are recommended next files/placeholders to add during hardening.

| # | File path | Purpose |
|---:|---|---|
| 01 | `README.md` | Root project description, V1 scope, quick start, demo users, and completion gate. |
| 02 | `.env.example` | Local development environment variables. |
| 03 | `.env.production.example` | Production deployment environment variable template. |
| 04 | `.gitignore` | Ignore node_modules, build outputs, env files, uploads, and cache. |
| 05 | `package.json` | Root scripts, workspace commands, V1 seed/verify/flow/audit commands. |
| 06 | `pnpm-workspace.yaml` | PNPM workspace package mapping. |
| 07 | `turbo.json` | Turborepo task configuration. |
| 08 | `tsconfig.base.json` | Shared TypeScript compiler settings and path aliases. |
| 09 | `docker-compose.yml` | Local Postgres and Redis services. |
| 10 | `.github/workflows/ci.yml` | GitHub Actions CI starter. |
| 11 | `docs/ARCHITECTURE.md` | Voltaire to AutoDeFi to ZONYCS to Hedera architecture overview. |
| 12 | `docs/V1_SCOPE.md` | Frozen V1 scope and boundaries. |
| 13 | `docs/DEAL_FLOW.md` | Dealer paid-in-full and borrower repayment lifecycle. |
| 14 | `docs/ADF_UTILITY.md` | ADF token utility, collateral, staking, boosts and governance. |
| 15 | `docs/STABLECOIN_RAILS.md` | Stable-value rails for loan money and accounting. |
| 16 | `docs/HEDERA.md` | Hedera/HBAR execution and token settlement layer. |
| 17 | `docs/OPERATOR_RUNBOOK_V1.md` | Operator startup, verification, and troubleshooting runbook. |
| 18 | `docs/V1_COMPLETION_CHECKLIST.md` | Checklist before calling V1 complete. |
| 19 | `docs/V1_STATUS.md` | Current repo/scaffold status and next steps. |
| 20 | `prisma/schema.prisma` | Central Prisma schema for users, dealers, deals, pools, payments, ADF, AI, reconciliation. |
| 21 | `prisma/seed.ts` | Root Prisma seed wrapper. |
| 22 | `scripts/v1-demo-constants.ts` | Shared IDs, demo users, wallets, and demo metadata. |
| 23 | `scripts/seed-defaults.ts` | Seeds base tier pools and ADF utility policy. |
| 24 | `scripts/seed-v1-demo.ts` | Seeds the full V1 demo lifecycle. |
| 25 | `scripts/verify-v1-demo.ts` | Verifies core V1 demo state. |
| 26 | `scripts/reset-v1-demo.ts` | Resets demo records in dependency-safe order. |
| 27 | `scripts/run-v1-flow.ts` | Runs seed, verify, dashboard snapshot, and end-to-end flow proof. |
| 28 | `scripts/reset-and-run-v1-flow.ts` | Resets and reruns the full V1 flow. |
| 29 | `scripts/v1-flow-summary.ts` | Prints latest V1 flow dashboard snapshot. |
| 30 | `scripts/validate-prisma.ts` | Formats, validates, and generates Prisma client. |
| 31 | `scripts/audit-v1-repo-structure.ts` | Checks required V1 repo paths. |
| 32 | `scripts/audit-v1-env.ts` | Checks required env template keys. |
| 33 | `scripts/audit-v1-ready.ts` | Runs readiness audit subset. |
| 34 | `scripts/security-check.ts` | Checks for obvious committed secret patterns. |
| 35 | `scripts/setup-v1-local.ts` | One-command local setup helper. |
| 36 | `scripts/complete-v1.ts` | Local completion gate command. |
| 37 | `apps/web/package.json` | Next.js web app package. |
| 38 | `apps/web/next.config.ts` | Next.js configuration. |
| 39 | `apps/web/tsconfig.json` | Web app TypeScript config. |
| 40 | `apps/web/app/globals.css` | AutoDeFi dark cyber-finance design tokens. |
| 41 | `apps/web/app/layout.tsx` | Root Next.js app layout. |
| 42 | `apps/web/app/autodefi/page.tsx` | AutoDeFi root route forwarding to institutional portal. |
| 43 | `apps/web/app/autodefi/institutional/page.tsx` | Main institutional portal page. |
| 44 | `apps/web/app/autodefi/dealer-command/page.tsx` | Dealer funding command center page. |
| 45 | `apps/web/app/autodefi/borrower-command/page.tsx` | Borrower servicing portal page. |
| 46 | `apps/web/app/autodefi/tier-pools/page.tsx` | LP/tier pool yield page. |
| 47 | `apps/web/app/autodefi/stable-treasury/page.tsx` | Stablecoin treasury page. |
| 48 | `apps/web/app/autodefi/adf-utility/page.tsx` | ADF utility/collateral page. |
| 49 | `apps/web/app/autodefi/ai-risk/page.tsx` | AI risk intelligence page. |
| 50 | `apps/web/components/autodefi/AutoDeFiShell.tsx` | Left command rail and page shell. |
| 51 | `apps/web/components/autodefi/PageHeader.tsx` | Standard page header component. |
| 52 | `apps/web/components/autodefi/CyberCard.tsx` | Glassmorphism panel component. |
| 53 | `apps/web/components/autodefi/StatTile.tsx` | Neon dashboard metric tile. |
| 54 | `services/auth/package.json` | Auth service package. |
| 55 | `services/auth/tsconfig.json` | Auth service TypeScript config. |
| 56 | `services/auth/src/main.ts` | Auth health service scaffold. |
| 57 | `services/finance/package.json` | Finance service package. |
| 58 | `services/finance/tsconfig.json` | Finance service TypeScript config. |
| 59 | `services/finance/src/main.ts` | Finance health service scaffold. |
| 60 | `services/ai/package.json` | AI service package. |
| 61 | `services/ai/tsconfig.json` | AI service TypeScript config. |
| 62 | `services/ai/src/main.ts` | AI health service scaffold. |
| 63 | `services/token/package.json` | Token service package. |
| 64 | `services/token/tsconfig.json` | Token service TypeScript config. |
| 65 | `services/token/src/main.ts` | Token health service scaffold. |
| 66 | `services/api-gateway/package.json` | API gateway package. |
| 67 | `services/api-gateway/tsconfig.json` | API gateway TypeScript config. |
| 68 | `services/api-gateway/src/main.ts` | Gateway health/services scaffold. |
| 69 | `packages/types/package.json` | Shared types package. |
| 70 | `packages/types/src/index.ts` | UserRole and RiskTier shared types. |
| 71 | `packages/config/package.json` | Shared config package. |
| 72 | `packages/config/src/index.ts` | Config package entry. |
| 73 | `packages/backend-auth/package.json` | Shared auth guard/decorator package. |
| 74 | `packages/backend-auth/src/index.ts` | Auth guard/decorator placeholders. |
| 75 | `packages/ui/package.json` | Shared UI package placeholder. |
| 76 | `packages/ui/src/index.ts` | Shared UI package entry. |
| 77 | `packages/sdk/package.json` | Shared SDK package placeholder. |
| 78 | `packages/sdk/src/index.ts` | Shared SDK package entry. |
| 79 | `contracts/hedera-autodefi/README.md` | Hedera contracts placeholder/readme. |
| 80 | `docs/API_CONTRACTS.md` | API contract testing plan placeholder. |
| 81 | `docs/DEPLOYMENT_V1.md` | Deployment plan placeholder. |
| 82 | `docs/FRONTEND_FALLBACKS_V1.md` | Frontend fallback/data safety plan. |
| 83 | `docs/VISUAL_SYSTEM_V1.md` | Visual design system lock. |
| 84 | `docs/PAGE_STYLING_AUDIT_V1.md` | Page styling audit checklist. |
| 85 | `docs/V1_GITHUB_READINESS_AUDIT.md` | GitHub readiness audit checklist. |
| 86 | `docs/V1_COMPLETION_GATE.md` | Final V1 completion gate definition. |
| 87 | `docs/PORTAL_POSITIONING.md` | Standalone institutional portal positioning. |
| 88 | `docs/V1_PERMISSION_MATRIX.md` | Role/permission matrix. |
| 89 | `docs/SECURITY_BOUNDARIES.md` | Security and private-key boundaries. |
| 90 | `docs/DEMO_SCENARIO.md` | Demo scenario details. |
| 91 | `docs/V1_FLOW_RUNNER.md` | End-to-end V1 flow runner documentation. |
| 92 | `docs/DASHBOARD_AGGREGATION.md` | Dashboard aggregation layer plan. |
| 93 | `docs/V1_DEPLOYMENT_CHECKLIST.md` | Deployment checklist. |
| 94 | `tests/api/v1-test-config.ts` | API test config placeholder. |
| 95 | `tests/api/v1-test-auth.ts` | API test auth helper placeholder. |
| 96 | `tests/api/v1-api-contracts.test.ts` | V1 API contract test placeholder. |
| 97 | `docs/thunder-client/autodefi-v1-api.json` | Thunder Client collection placeholder. |
| 98 | `docs/thunder-client/autodefi-v1-local-env.json` | Thunder Client local environment placeholder. |
| 99 | `docs/V1_1_V2_BACKLOG.md` | Items moved out of V1 into V1.1/V2 backlog. |